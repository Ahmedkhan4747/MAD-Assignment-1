# CurrencyExchange
This is an android app that exchanges currency of different countries.
